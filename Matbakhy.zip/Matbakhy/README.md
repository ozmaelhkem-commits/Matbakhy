# مطبخي (Matbakhy)

تطبيق أندرويد بيغلّف صفحة مطبخي (app/src/main/assets/index.html) داخل WebView، ويشتغل بدون إنترنت.
مكتبتا QR بتتحمّلا وقت البناء من build.yml. التوقيع ثابت (app/debug.keystore) عشان التحديثات تتثبت فوق القديمة.
