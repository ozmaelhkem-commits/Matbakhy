# مطبخي (Matbakhy)

تطبيق أندرويد بيغلّف صفحة مطبخي (app/src/main/assets/index.html) داخل WebView، ويشتغل بدون إنترنت.
مكتبتا QR (qrcode.min.js وjsQR.min.js) بتتحمّلا وقت البناء من ملف build.yml وبتتحط في app/src/main/assets.
